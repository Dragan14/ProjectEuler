import UIKit

let startTime = Date().timeIntervalSince1970

precedencegroup PowerPrecedence { higherThan: MultiplicationPrecedence }
infix operator ^^ : PowerPrecedence
func ^^ (radix: Int, power: Int) -> Int {
    return Int(pow(Double(radix), Double(power)))
}

var sum = 0
var squareSum = 0

for number in 1...10000 {
    squareSum = squareSum + number^^2
    sum = sum + number
}

print(sum^^2 - squareSum)

let endTime = Date().timeIntervalSince1970
print(endTime - startTime)
