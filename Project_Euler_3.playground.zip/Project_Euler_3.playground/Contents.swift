import UIKit

var factor = 1

var multiple = 600851475143

func checkPrime(number: Int) -> Bool {
    var divisor = 2
    var primality = true
        
    repeat {
        
        if number.isMultiple(of: divisor) == true {
            primality = false
        } else {
            primality = true
            divisor = divisor + 1
        }
        
    } while primality == true && divisor*divisor <= number
    
    return primality
}

repeat {

    if checkPrime(number: factor) == true && multiple.isMultiple(of: factor) {
        multiple = multiple/factor
    }
        
    factor = factor + 2
    
} while factor*factor < multiple

print(multiple)
