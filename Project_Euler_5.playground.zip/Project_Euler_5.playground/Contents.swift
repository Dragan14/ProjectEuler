import UIKit

precedencegroup PowerPrecedence { higherThan: MultiplicationPrecedence }
infix operator ^^ : PowerPrecedence
func ^^ (radix: Int, power: Int) -> Int {
    return Int(pow(Double(radix), Double(power)))
}

func checkPrime(inputNumber: Int) -> Bool {
    var divisor = 2
    var primality = true
        
    repeat {
        
        if inputNumber.isMultiple(of: divisor) == true && inputNumber != divisor {
            primality = false
        } else {
            primality = true
            divisor = divisor + 1
        }
        
    } while primality == true && divisor*divisor <= inputNumber
    
    return primality
}

func primeFactor(inputNumber: Int) -> [Int] {
    var number = inputNumber
    
    var factor = 2
    
    var factors : [Int] = []
    
    repeat {
        
        if number.isMultiple(of: factor) && checkPrime(inputNumber: factor) == true {
            number = number/factor
            factors.append(factor)
            factor = 2
        } else {
            factor = factor + 1
        }
        
        if checkPrime(inputNumber: number) == true {
            factors.append(number)
        }
        
    } while checkPrime(inputNumber: number) == false
    
    return factors
}

func numberOfRepetitions(inputArray: [Int], inputNumber: Int) -> Int {
    var reps = 0
    for index in 0...inputArray.count-1 {
        if inputArray[index] == inputNumber {
            reps = reps + 1
        }
    }
    return reps
}

var answer = 1
var newHighest = 1

for checkAgainst in 2...20 {
    newHighest = 0
    var number = 20
    
    if checkPrime(inputNumber: checkAgainst) == true {
        
        repeat {
            if newHighest <= numberOfRepetitions(inputArray: primeFactor(inputNumber: number), inputNumber: checkAgainst) {
                newHighest = numberOfRepetitions(inputArray: primeFactor(inputNumber: number), inputNumber: checkAgainst)
                
            }
            
            number = number - 1
            
        } while number >= 2
        
        answer = answer * checkAgainst^^newHighest
    }
}

print(answer)
