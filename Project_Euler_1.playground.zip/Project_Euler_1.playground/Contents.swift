import UIKit

var sum = 0

for number in 1...999 {
    if number.isMultiple(of: 3) || number.isMultiple(of: 5) {
        sum = sum + number
    }
}

print(sum)
