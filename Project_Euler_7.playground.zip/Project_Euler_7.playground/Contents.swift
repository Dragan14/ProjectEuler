import UIKit
import Foundation

let startTime = Date().timeIntervalSince1970

func checkPrime(number: Int) -> Bool {
    var divisor = 2
    var primality = true
        
    repeat {
        
        if number.isMultiple(of: divisor) == true {
            primality = false
        } else {
            primality = true
            divisor = divisor + 1
        }
        
    } while primality == true && divisor*divisor <= number
    
    return primality
}

func UpperBoundPrime(number: Int) -> Int {
    if number < 6 {
        return 13
    }
    
    return number*Int(log(Double(number)) + log(log(Double(number))))
}

var reps = 0
var number = 3

repeat {
    if (number + 1).isMultiple(of: 6) || (number - 1).isMultiple(of: 6) {
        if checkPrime(number: number) == true {
            reps = reps + 1
        }
    }

    number = number + 2
} while number <= UpperBoundPrime(number: 10001)

print(number - 1)

let endTime = Date().timeIntervalSince1970
print(endTime - startTime)
