import UIKit

var prime = true

var factor = 1

var primes : [Int] = []

var sumOfPrimes = 0

var number = 2

var hasBeenFound = false

var primeFound = false

func checkPrime(number: Int) -> Bool {
    var divisor = 2
    var primality = true
        
    repeat {
        
        if number.isMultiple(of: divisor) == true {
            primality = false
        } else {
            primality = true
            divisor = divisor + 1
        }
        
    } while primality == true && divisor*divisor <= number
    
    return primality
}

repeat {
    
    repeat {
        
        if number.isMultiple(of: factor) == true && factor != 1 {
            prime = false
        } else {
            prime = true
            factor = factor + 1
        }
        
    } while prime == true && factor*factor <= number
    
    factor = 1
    
    if prime == true && sumOfPrimes + number < 1000000 {
        primes.append(number)
        sumOfPrimes = primes.reduce(0, +)
    }
    
    if sumOfPrimes + number > 1000000 {
        hasBeenFound = true
    }
            
    number = number + 1
    
} while hasBeenFound == false

var counter = 1

var reps = 0

var answerFound = false

var backUpArray = primes

repeat {

    primes = backUpArray
        
    for _ in 1...counter {
        
        primes.removeFirst()

    }
    
    sumOfPrimes = primes.reduce(0, +)
    
    answerFound = checkPrime(number: sumOfPrimes)

    if answerFound == false {
        repeat {
            
            primes.removeLast()

            reps = primes.count
            
            answerFound = checkPrime(number: sumOfPrimes)
            
        } while answerFound == false && reps >= 2
    }

    counter = counter + 1
    
} while answerFound == false

if answerFound ==  true {
    print("The answer is \(sumOfPrimes)")
}
