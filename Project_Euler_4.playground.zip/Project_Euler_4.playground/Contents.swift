import UIKit

func checkPalindrome(number: Int) -> Bool {
    
      var palindrome = true

//    let digits = "\(number)".compactMap{ $0.wholeNumberValue }
//
//    var start = 0
//    var end = digits.count - 1
//
//    repeat {
//
//        if digits[start] != digits[end] {
//            palindrome = false
//        }
//
//        start = start + 1
//        end = end - 1
//
//    } while start != end + 1 && palindrome == true && start != end
    
    if "\(number)" == String("\(number)".reversed()) {
        palindrome = true
    } else {
        palindrome = false
    }

    return palindrome
}

//var firstNumber = 999
//var secondNumber = 999
//var number = 0
//var answerFound = false
//var newHighest = 0
//
//repeat {
//
//    number = firstNumber*secondNumber
//
//    if checkPalindrome(number: number) == true {
//        if number > newHighest {
//            newHighest = number
//        }
//    }
//
//    if secondNumber == 100  {
//        secondNumber = 999
//        firstNumber = firstNumber - 1
//    } else {
//        secondNumber = secondNumber - 1
//    }
//
//    if firstNumber * 999 < newHighest {
//        answerFound = true
//    }
//
//} while answerFound == false
//
//print(newHighest)

var newHighest = 0

for firstNumber in 900...999{
    for secondNumber in 900...999{
        let result = firstNumber * secondNumber
        if checkPalindrome(number: result) == true && newHighest < result {
            newHighest = result
        }
    }
}

print(newHighest)
