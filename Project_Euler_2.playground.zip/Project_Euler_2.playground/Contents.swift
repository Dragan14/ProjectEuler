import UIKit

var fibArray : [Int] = [1,2]

var backUpArray : [Int] = []

var newNumber = 0

var end = false

repeat {
    newNumber = fibArray.reduce(0, +)
    
    if newNumber < 4000000 {
        if newNumber.isMultiple(of: 2) == true && newNumber != 1 {
            backUpArray.append(newNumber)
        }
        fibArray.append(newNumber)
        fibArray.removeFirst()
    } else {
        end = true
    }
} while end == false

print(backUpArray.reduce(0, +))
